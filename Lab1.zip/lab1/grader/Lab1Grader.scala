object Lab1Grader {
  def main(args: Array[String]) {
    (new Lab1Grading).execute(stats = true)
  }
}